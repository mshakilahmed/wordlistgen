__version__ = "1.0.2"
__version_info__ = (1, 0, 2)


def get_version():
    return __version__
